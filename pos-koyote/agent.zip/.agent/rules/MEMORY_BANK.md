Memory Bank update rules
- Update Memory Bank after meaningful changes to code or specs.
- activeContext.md must reflect current focus in present tense.
- progress.md must reflect actual completed work.
- techContext.md must be updated when dependencies or stack change.
