# Agent Contract

All agents under `.agent/agents/` MUST declare:

## Required sections
- Name
- Role
- Domain
- Capabilities
- Allowed actions
- Forbidden actions
- Input expectations
- Output format

## Discovery rules
- Agents are discoverable by matching `Domain` and `Capabilities`
- Orchestrator may consult multiple agents
- Agents provide advice, not final decisions
- Absence of a matching agent is allowed and must not block flow

## Invocation rules
- Agents are consulted via reasoning, not execution
- Orchestrator summarizes and decides
