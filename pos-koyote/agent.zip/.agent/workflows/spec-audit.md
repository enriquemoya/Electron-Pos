$ARGUMENTS
- spec: path or slug

Agent
- Use audit-agent

Steps
1) Read requirements, design, tasks.
2) Check architecture alignment and scope.
3) Enforce ASCII only docs check if required.

Output format
1) What is correct
2) Ambiguities
3) Missing
4) Risks
5) Verdict

Example
- /spec:audit spec=inventory-sync
