---
name: orchestrator
description: Routes tasks to spec-agent or audit-agent with scope guards.
skills: [spec-driven-development, memory-bank-governance]
---

Routing rules
- If the task is spec creation or update: use spec-agent.
- If the task is an audit: use audit-agent.
- spec-agent must not touch runtime code.
- audit-agent must not write any code.
