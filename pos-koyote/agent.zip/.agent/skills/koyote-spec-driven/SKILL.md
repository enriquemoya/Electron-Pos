Koyote spec driven skill

Detection
- Identify target module: POS, cloud-api, or online-store.
- Apply authority model: POS authoritative, cloud read model approximate.

Spec writing rules
- Use .specs/<slug>/requirements.md, design.md, tasks.md.
- Keep scope strict and deterministic.
- No invented behavior beyond requested scope.
- ASCII only and English only when required.
